import React from 'react';
import { Layout } from './components/Layout';
import { ReviewsSection } from './components/ReviewsSection';
import { ReferencesSection } from './components/ReferencesSection';
import { AboutSection } from './components/AboutSection';
import { BlogSection } from './components/BlogSection';
import { PainPointsSection } from './components/PainPointsSection';
import { PainSolutionSection } from './components/PainSolutionSection';
import { BentoGrid } from './components/BentoGrid';
import { Link } from 'react-router-dom';
import { Code, Palette, Globe, Smartphone, Bot, FileText, Building2, Store, Sparkles, Scissors, Briefcase, GraduationCap, ShoppingBag, Truck, Building } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/utils/cn';
import { useTheme } from '@/hooks/useTheme';

interface AppProps {
  darkMode: boolean;
  setDarkMode: (value: boolean) => void;
}

export default function App({ darkMode, setDarkMode }: AppProps) {
  const services = [
    {
      icon: Code,
      title: 'Webentwicklung',
      description: 'Moderne Websites mit neuester Technologie für maximale Performance.',
      link: '/services/webentwicklung',
      image: 'https://images.unsplash.com/photo-1517134191118-9d595e4c8c2b?auto=format&fit=crop&w=1200&q=80',
      size: 'large',
      emoji: '⚡️'
    },
    {
      icon: Palette,
      title: 'UI/UX Design',
      description: 'Conversion-optimierte Interfaces die begeistern.',
      link: '/services/webdesign',
      image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=1200&q=80',
      size: 'small',
      emoji: '🎨'
    },
    {
      icon: Globe,
      title: 'Online Shops',
      description: 'E-Commerce Lösungen die nachweislich verkaufen.',
      link: '/services/online-shop',
      image: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=1200&q=80',
      size: 'small',
      emoji: '🛍️'
    },
    {
      icon: Smartphone,
      title: 'Mobile Apps',
      description: 'Native und Cross-Platform Apps für iOS & Android.',
      link: '/services/mobile-development',
      image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&w=1200&q=80',
      size: 'small',
      emoji: '📱'
    },
    {
      icon: Bot,
      title: 'KI Automation',
      description: 'Intelligente Prozessautomatisierung für mehr Effizienz.',
      link: '/services/ki-automation',
      image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1200&q=80',
      size: 'large',
      emoji: '🤖'
    },
    {
      icon: FileText,
      title: 'Print & Design',
      description: 'Hochwertige Druckprodukte die Ihre Marke stärken.',
      link: '/services/print',
      image: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=1200&q=80',
      size: 'small',
      emoji: '🎯'
    }
  ];

  const industries = [
    {
      icon: Store,
      title: 'Gastronomie & Restaurants',
      description: 'Digitale Lösungen für die moderne Gastronomie.',
      link: '/branchenwelt/gastronomie',
      image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
      size: 'large',
      emoji: '🍽️'
    },
    {
      icon: Building2,
      title: 'Handwerk & Bau',
      description: 'Digitale Präsenz für Handwerksbetriebe.',
      link: '/branchenwelt/handwerk-bau',
      image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1200&q=80',
      size: 'small',
      emoji: '🏗️'
    },
    {
      icon: Scissors,
      title: 'Kosmetik & Beauty',
      description: 'Digitale Beauty & Wellness Lösungen.',
      link: '/branchenwelt/kosmetik',
      image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1200&q=80',
      size: 'small',
      emoji: '💅'
    },
    {
      icon: Briefcase,
      title: 'Consulting & Beratung',
      description: 'Professionelle Präsenz für Berater.',
      link: '/branchenwelt/consulting',
      image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80',
      size: 'large',
      emoji: '💼'
    },
    {
      icon: GraduationCap,
      title: 'Coaches & Trainer',
      description: 'Digitale Tools für Coaches.',
      link: '/branchenwelt/coaches',
      image: 'https://images.unsplash.com/photo-1475823678248-624fc6f85785?auto=format&fit=crop&w=1200&q=80',
      size: 'small',
      emoji: '🎯'
    },
    {
      icon: ShoppingBag,
      title: 'E-Commerce',
      description: 'Professionelle Online-Shop Lösungen.',
      link: '/branchenwelt/e-commerce',
      image: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=1200&q=80',
      size: 'small',
      emoji: '🛍️'
    },
    {
      icon: Truck,
      title: 'Logistik & Transport',
      description: 'Digitale Lösungen für Logistikunternehmen.',
      link: '/branchenwelt/logistik',
      image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1200&q=80',
      size: 'small',
      emoji: '🚚'
    },
    {
      icon: Building,
      title: 'Immobilien',
      description: 'Digitale Präsenz für Immobilienmakler.',
      link: '/branchenwelt/immobilien',
      image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1200&q=80',
      size: 'small',
      emoji: '🏢'
    },
    {
      icon: Sparkles,
      title: 'Agenturen',
      description: 'White Label Services für Agenturen.',
      link: '/branchenwelt/agenturen',
      image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80',
      size: 'large',
      emoji: '✨'
    }
  ];

  return (
    <Layout darkMode={darkMode} setDarkMode={setDarkMode}>
      <motion.header 
        className="container mx-auto px-4 pt-32 pb-20 text-center relative z-10"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <div className="max-w-4xl mx-auto">
          <motion.h1 
            className="text-7xl md:text-8xl font-bold mb-6 font-space-grotesk"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          >
            Zukunft ist <span className="kb-digital">(kb)</span> digital
          </motion.h1>
          <motion.p 
            className="text-2xl mb-8 font-space-grotesk"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Ihre Vision. Unsere Expertise.
          </motion.p>
          <motion.p 
            className="text-xl opacity-90 mb-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            Wir entwickeln digitale Lösungen, die nicht nur begeistern, sondern messbare Ergebnisse liefern.
            Von der Strategie bis zur Umsetzung - alles aus einer Hand.
          </motion.p>
          <motion.div 
            className="flex gap-4 justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <Link
              to="/kontakt"
              className="bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 px-8 py-3 rounded-lg font-semibold text-white hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5"
            >
              Projekt starten
            </Link>
            <a
              href="#services"
              className={cn(
                "px-8 py-3 rounded-lg font-semibold transition-all duration-300",
                darkMode
                  ? "bg-gray-800 text-white hover:bg-gray-700"
                  : "bg-gray-100 text-gray-900 hover:bg-gray-200"
              )}
            >
              Mehr erfahren
            </a>
          </motion.div>
        </div>
      </motion.header>

      <PainPointsSection />

      <PainSolutionSection
        solution={{
          title: "Digitale Exzellenz ✨",
          description: "Wir verwandeln Ihre digitale Präsenz in ein Erlebnis, das begeistert und konvertiert."
        }}
        benefits={[
          {
            title: "Conversion-Optimierung",
            description: "Websites, die Besucher in Kunden verwandeln."
          },
          {
            title: "Unique Branding",
            description: "Unverwechselbare Markenidentität, die im Gedächtnis bleibt."
          },
          {
            title: "Technische Perfektion",
            description: "Modernste Technologien für optimale Performance."
          }
        ]}
      />

      <section id="services" className="relative z-10 py-20">
        <div className="container mx-auto px-4">
          <BentoGrid 
            items={services} 
            title="Unsere Services ⚡️"
            description="Von der Konzeption bis zur Umsetzung - alles aus einer Hand."
          />
        </div>
      </section>

      <section className="relative z-10 py-20">
        <div className="container mx-auto px-4">
          <BentoGrid 
            items={industries} 
            title="Branchen 🎯"
            description="Spezialisierte Lösungen für Ihre Branche."
          />
          <div className="text-center mt-12">
            <Link
              to="/branchenwelt"
              className="bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 px-8 py-3 rounded-lg font-semibold text-white hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5"
            >
              Alle Branchen entdecken
            </Link>
          </div>
        </div>
      </section>

      <AboutSection />
      <ReviewsSection />
      <ReferencesSection />
      <BlogSection />
    </Layout>
  );
}