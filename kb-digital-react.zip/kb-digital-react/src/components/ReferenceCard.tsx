import React from 'react';
import { ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/utils/cn';
import { useTheme } from '@/hooks/useTheme';

interface ReferenceCardProps {
  name: string;
  url: string;
  desc: string;
  image: string;
  logo?: string;
  services?: string[];
}

export function ReferenceCard({ name, url, desc, image, logo, services = [] }: ReferenceCardProps) {
  const { darkMode } = useTheme();
  const [logoError, setLogoError] = React.useState(false);
  
  return (
    <motion.div 
      className="space-y-3"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <h3 className="text-xl font-bold flex items-center gap-2">
        {name}
        <a 
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className={cn(
            "transition-colors",
            darkMode ? 'text-white hover:text-purple-400' : 'text-black hover:text-purple-600'
          )}
        >
          <ExternalLink className="w-4 h-4" />
        </a>
      </h3>
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="bento-item block"
      >
        <div className="aspect-video relative">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover transform transition-all duration-500 ease-out group-hover:scale-105 group-hover:filter group-hover:brightness-110"
            loading="lazy"
          />
          
          {/* Logo Overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            {logo && !logoError ? (
              <div className="w-32 h-32 flex items-center justify-center p-4 transform transition-transform duration-500 ease-out group-hover:scale-105">
                <img
                  src={logo}
                  alt={`${name} logo`}
                  className={cn(
                    "w-full h-full object-contain",
                    darkMode ? "brightness-0 invert" : "brightness-0"
                  )}
                  loading="lazy"
                  onError={() => setLogoError(true)}
                />
              </div>
            ) : (
              <div className="w-32 h-32 flex items-center justify-center transform transition-transform duration-500 ease-out group-hover:scale-105">
                <svg 
                  viewBox="0 0 125.62 94.3" 
                  className={cn(
                    "w-16 h-16 drop-shadow-lg",
                    darkMode ? "text-white/70" : "text-black/70"
                  )}
                >
                  <g className="fill-current">
                    <path d="M49.47,0h26.04c-16.47,15.73-32.95,31.47-49.42,47.21,16.45,15.69,32.9,31.39,49.34,47.09h-26.01C32.91,78.62,16.44,62.92,0,47.19v-.08c.79-.62,1.53-1.3,2.22-2.02C17.97,30.06,33.72,15.03,49.47,0Z"/>
                    <path d="M75.43,15.03c5.78,0,11.55,0,17.32,0,10.96,10.49,21.92,21,32.87,31.5h0c-10.87,10.53-21.85,20.93-32.72,31.45-5.8.05-11.59.02-17.38.02,10.92-10.5,21.89-20.95,32.81-31.46-10.98-10.49-21.94-20.99-32.89-31.51Z"/>
                    <path d="M68.47,32.58l-14.57,14.57,14.57,14.57,14.57-14.57-14.57-14.57Z"/>
                  </g>
                </svg>
              </div>
            )}
          </div>

          {/* Hover Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <p className="text-white text-sm mb-4">{desc}</p>
              {services.length > 0 && (
                <ul className="flex flex-wrap gap-2">
                  {services.map((service, index) => (
                    <li 
                      key={index}
                      className="text-xs px-2 py-1 rounded-full bg-white/20 text-white"
                    >
                      {service}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </a>
    </motion.div>
  );
}