'use client';

import React from 'react';
import { Navigation } from './navigation/Navigation';
import { Footer } from './footer/Footer';
import { ScrollToTop } from './ScrollToTop';
import { BackgroundEffects } from './BackgroundEffects';
import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/utils/cn';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { darkMode } = useTheme();
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
  }, []);

  // Prevent hydration mismatch by only rendering theme-dependent content after mount
  if (!mounted) {
    return null;
  }

  return (
    <div className={cn(
      "min-h-screen",
      darkMode ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'
    )}>
      <BackgroundEffects />
      <Navigation />
      <main className="relative">{children}</main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}