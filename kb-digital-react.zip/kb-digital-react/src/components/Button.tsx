import React from 'react';
import { Link } from 'react-router-dom';
import { LucideIcon } from 'lucide-react';
import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/utils/cn';
import { motion } from 'framer-motion';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  href?: string;
  onClick?: () => void;
  icon?: LucideIcon;
  className?: string;
  disabled?: boolean;
  loading?: boolean;
  type?: 'button' | 'submit' | 'reset';
}

export function Button({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  href, 
  onClick, 
  icon: Icon, 
  className = '',
  disabled = false,
  loading = false,
  type = 'button'
}: ButtonProps) {
  const { darkMode } = useTheme();
  
  const baseStyles = cn(
    "relative inline-flex items-center justify-center gap-2 font-semibold rounded-lg transition-all duration-300",
    {
      'px-4 py-2 text-sm': size === 'sm',
      'px-6 py-3 text-base': size === 'md',
      'px-8 py-4 text-lg': size === 'lg',
      'opacity-50 cursor-not-allowed': disabled,
      'cursor-wait': loading,
      'bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 text-white hover:shadow-lg hover:-translate-y-0.5': variant === 'primary',
      [darkMode
        ? 'bg-gray-800 text-white hover:bg-gray-700'
        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
      ]: variant === 'secondary',
      [darkMode
        ? 'border-2 border-white text-white hover:bg-white hover:text-gray-900'
        : 'border-2 border-gray-900 text-gray-900 hover:bg-gray-900 hover:text-white'
      ]: variant === 'outline',
      [darkMode
        ? 'text-white hover:bg-white/10'
        : 'text-gray-900 hover:bg-gray-900/10'
      ]: variant === 'ghost'
    },
    className
  );

  const content = (
    <>
      {loading ? (
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-5 h-5 border-2 border-current border-t-transparent rounded-full"
        />
      ) : (
        <span className="relative z-10 flex items-center gap-2">
          {Icon && <Icon className="w-5 h-5" />}
          {children}
        </span>
      )}
    </>
  );

  if (href) {
    return (
      <Link to={href} className={cn(baseStyles, 'group')}>
        {content}
      </Link>
    );
  }

  return (
    <button 
      onClick={onClick} 
      className={cn(baseStyles, 'group')}
      disabled={disabled || loading}
      type={type}
    >
      {content}
    </button>
  );
}