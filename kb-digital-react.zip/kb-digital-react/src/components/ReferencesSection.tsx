import React from 'react';
import { Link } from 'react-router-dom';
import { ReferenceCard } from './ReferenceCard';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';

interface ReferencesSectionProps {}

export function ReferencesSection({}: ReferencesSectionProps) {
  const { darkMode } = useTheme();
  
  const references = [
    {
      name: "Restaurant Alanya",
      url: "https://www.alanya-eschenburg.de",
      desc: "Modernes Restaurant mit mediterraner Küche",
      image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Butrin Etiketten",
      url: "https://www.butrin-etiketten.com",
      desc: "Professionelle Etikettenlösungen",
      image: "https://images.unsplash.com/photo-1585559604830-91802a8f05f2?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "BFO Insektenschutz",
      url: "https://www.bfo-insektenschutz.de",
      desc: "Innovative Insektenschutzsysteme",
      image: "https://images.unsplash.com/photo-1632935190508-bd46801c14af?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Böhm & Becker",
      url: "https://www.boehmundbecker.de",
      desc: "Professionelle Bauunternehmen",
      image: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Kutan GalaBau",
      url: "https://www.galabau-kutan.de",
      desc: "Kreative Gartengestaltung",
      image: "https://images.unsplash.com/photo-1558904541-efa843a96f01?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "AKAS Rümpel",
      url: "https://www.akas-ruempel.de",
      desc: "Professionelle Entrümpelung",
      image: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=800&q=80"
    }
  ];

  return (
    <section className={`py-20 ${darkMode ? 'bg-gray-800/50' : 'bg-gray-50'}`}>
      <div className="container mx-auto px-4">
        <motion.h2 
          className="text-4xl font-bold mb-16 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          Unsere Referenzen ⭐️
        </motion.h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {references.map((ref, index) => (
            <ReferenceCard key={index} {...ref} />
          ))}
        </div>
        <div className="text-center mt-12">
          <Link
            to="/referenzen"
            className={`px-8 py-3 ${
              darkMode 
                ? 'bg-white text-gray-900 hover:bg-gray-200' 
                : 'bg-gray-900 text-white hover:bg-gray-800'
            } rounded-lg font-semibold transition-all duration-300`}
          >
            Alle Referenzen ansehen
          </Link>
        </div>
      </div>
    </section>
  );
}