// ... previous imports remain the same

export function CaseStudyCard({
  slug,
  title,
  client,
  description,
  image,
  services
}: CaseStudyCardProps) {
  const { darkMode } = useTheme();

  return (
    <motion.article
      className={cn(
        "group relative overflow-hidden rounded-[2.5rem]",
        darkMode ? 'bg-gray-800/50' : 'bg-gray-50'
      )}
      whileHover={{ y: -5 }}
      transition={{ duration: 0.2 }}
    >
      <Link to={`/referenzen/${slug}`} className="block">
        <div className="aspect-[16/9] relative rounded-[2.5rem] overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent" />
        </div>
        <div className="p-6">
          {/* ... rest of the card content remains the same */}
        </div>
      </Link>
    </motion.article>
  );
}